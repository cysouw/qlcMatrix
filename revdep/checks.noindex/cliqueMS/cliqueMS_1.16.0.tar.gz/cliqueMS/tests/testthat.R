library(testthat)
library(cliqueMS)

test_check("cliqueMS")
